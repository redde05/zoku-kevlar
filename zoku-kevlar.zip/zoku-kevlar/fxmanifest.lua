fx_version 'cerulean'
game 'gta5'
lua54 'yes'

shared_script {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua'
}

client_scripts {
    'cl_kevlar.lua'
}

server_scripts {
    'sv_kevlar.lua'
}
